import express from 'express';
import http from 'http';
import cors from 'cors';
import { Server } from 'socket.io';

const app = express();
app.use(cors({ origin: (o, cb) => cb(null, true) }));
app.get('/', (_, res) => res.send('Signaling OK'));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: (o, cb) => cb(null, true), methods: ['GET','POST'] }
});

io.on('connection', (socket) => {
  socket.on('entrar-sala', ({ sala, nome }) => {
    socket.join(sala);
    const count = io.sockets.adapter.rooms.get(sala)?.size || 1;
    socket.emit('pronto', { participantes: count });
    socket.to(sala).emit('alguem-entrou', { id: socket.id, nome });
  });

  socket.on('oferta', ({ sala, descricao }) => {
    socket.to(sala).emit('oferta', socket.id, descricao);
  });

  socket.on('resposta', ({ sala, descricao }) => {
    socket.to(sala).emit('resposta', descricao);
  });

  socket.on('candidato', ({ sala, candidato }) => {
    socket.to(sala).emit('candidato', candidato);
  });

  socket.on('disconnecting', () => {
    for (const sala of socket.rooms) {
      if (sala !== socket.id) io.to(sala).emit('peer-saiu');
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Signaling on port', PORT));
